Meteor.Collection.insecure = true;
